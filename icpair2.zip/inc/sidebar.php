<div class="head-style">
    <h3><span>Important Dates</span></h3><hr class="style-two">
    </div>
<div class="date-style">
<h5 class="alert alert-info">PAPER SUBMISSION</h5>
<ul class="ps">
  <li><span class="sym">&#9732;</span> &nbsp;<span class="date-tit">Openning:</span><span class="date-con"> 10<sup>th</sup> feb 2020</span></li>
  <li><span class="sym">&#9732;</span> &nbsp;<span class="date-tit">Closing:</span><span class="date-con"> 29<sup>th</sup>  feb 2020</span></li>
</ul>
<hr>
<h5 class="alert alert-info">NOTIFICATION OF ACCEPTANCE</h5>
<ul>
   <li><span class="sym">&#9732;</span> &nbsp;<span class="date-tit"></span><span class="date-con"> 06<sup>th</sup>  March 2020</span></li>
</ul>
<hr>
<h5 class="alert alert-info cap">Last Date for Registration</h5>
<ul>
   <li><span class="sym">&#9732;</span> &nbsp;<span class="date-tit"></span><span class="date-con">16<sup>th</sup> March 2020 </span></li>
</ul>
</div>

<!--downloads section-->
   <div class="head-style">
    <h3><span>Downloads</span></h3><hr class="style-two">
     </div>
    <div class="date-style"> 
    <ul class="ps">
    <li><span class="sym">&#9732;</span> &nbsp;<span class="date-tit"><a href="#">ICCI-2019 Brochure</a></span></li>
    <li><span class="sym">&#9732;</span> &nbsp;<span class="date-tit"><a href="paperformat.doc", download>Paper Format
    </a></span></li><hr>
</ul>
</div>
<!--downloads section ends-->
<!--quick enquiry section starts here-->
<div class="head-style">
    <h3><span>Quick Enquiry</span></h3><hr class="style-two">
     </div>
     <div class="qf">
      <h4>Please fill the form.</h4><hr>
 <form action="enquiry.php" method="POST">
    <div class="form-group">
      <!--<label for="email">Name:</label>-->
      <input type="name" class="form-control" id="name" placeholder="Your Name" name="name" required>
    </div>
    <div class="form-group">
      <!--<label for="pwd">Email:</label>-->
      <input type="email" class="form-control" id="email" placeholder="your E-mail" name="email" required>
    </div>
    <div class="form-group">
      <!--<label for="pwd">Mobile Number:</label>-->
      <input type="number" class="form-control" id="number" placeholder="Your mobile number" name="number" required>
    </div>
    <div class="form-group">
      <input type="text" class="form-control" id="text" placeholder="Your College/University Name" name="cname" required>
    </div>
   <div class="form-group">
    <textarea class="form-control" id="textarea3" rows="7" placeholder="Message" name="message"></textarea>
</div>
    <input type="submit" class="btn btn-default" value="Submit">
  </form>
     </div>
<!--quick enquiry section ends here-->
  </div>